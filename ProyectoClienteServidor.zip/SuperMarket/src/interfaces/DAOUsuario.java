/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.Usuario;

/**
 *
 * @author ovied
 */
public interface DAOUsuario {
   
    public void registrar(Usuario usuario);
    public void modificar(Usuario usuario);    
    public void eliminar(int usuarioId);
    public List<Usuario> listar(String nombre);
    public Usuario obtenerUsuario(int usuarioId);
}
