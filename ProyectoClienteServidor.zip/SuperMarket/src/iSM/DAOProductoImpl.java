/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iSM;

import db.Database;
import interfaces.DAOProducto;
import db.Database;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import modelos.Producto;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelos.Usuario;


/**
 *
 * @author ovied
 */
public class DAOProductoImpl extends Database implements DAOProducto{
    
    @Override
    public void registrar(Producto producto)
    {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO productos(id, nombre, tipo, cantidad, precio, total) VALUES(?,?,?,?,?,?);");
            st.setString(1, producto.getId());
            st.setString(2, producto.getNombre());
            st.setString(3, producto.getTipo());
            st.setString(4, producto.getCantidad());
            st.setString(5, producto.getPrecio());
            st.setInt(6, producto.getTotal());
            
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }
    
    @Override
    public List<Producto> listar(String id)
    {
        List<Producto> lista = null;
        try {
            this.Conectar();
            String Query = id.isEmpty() ? "SELECT * FROM productos;" : "SELECT * FROM productos WHERE id LIKE '%" + id + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Producto producto = new Producto();
                producto.setId(rs.getString("id"));
                producto.setNombre(rs.getString("nombre"));
                producto.setTipo(rs.getString("tipo"));
                producto.setCantidad(rs.getString("cantidad"));
                producto.setPrecio(rs.getString("precio"));
                producto.setTotal(rs.getInt("total"));
                
                
                lista.add(producto);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
        return lista;
    }
    
    @Override
    public void eliminar(String productoId)
    {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM productos WHERE id = ?;");
            st.setString(1, productoId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }
    
    @Override
    public Producto obtenerProducto(int productoId)
    {
        Producto producto = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM productos WHERE id = ? LIMIT 1;");
            st.setInt(1, productoId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                producto = new Producto();
                producto.setId(rs.getString("id"));
                producto.setNombre(rs.getString("nombre"));
                producto.setTipo(rs.getString("tipo"));
                producto.setCantidad(rs.getString("cantidad"));
                producto.setPrecio(rs.getString("precio"));
                
                /*producto.setStock(rs.getInt("stock"));
                producto.setAvailable(rs.getInt("available"));*/
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
        return producto;
    }
    
    
    
}
