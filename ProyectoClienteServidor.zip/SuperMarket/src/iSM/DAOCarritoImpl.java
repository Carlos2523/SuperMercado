/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iSM;
import db.Database;
import interfaces.DAOCarrito;
import modelos.Carrito;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author ovied
 */
public class DAOCarritoImpl extends Database implements DAOCarrito{
    @Override
    public void registrar(Carrito carrito)
    {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO carrito(id, producto, cantidad, precio, total) VALUES(?,?,?,?,?);");
            st.setString(1, carrito.getId());
            st.setString(2, carrito.getProducto());
            st.setString(3, carrito.getCantidad());
            st.setString(4, carrito.getPrecio());
            st.setString(5, carrito.getTotal());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }
    
     @Override
    public List<Carrito> listar(String id)
    {
        List<Carrito> lista = null;
        try {
            this.Conectar();
            String Query = id.isEmpty() ? "SELECT * FROM carrito;" : "SELECT * FROM carrito WHERE id LIKE '%" + id + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Carrito carrito = new Carrito();
                carrito.setId(rs.getString("id"));
                carrito.setProducto(rs.getString("producto"));
                carrito.setCantidad(rs.getString("cantidad"));
                carrito.setPrecio(rs.getString("precio"));
                carrito.setTotal(rs.getString("total"));
                
                lista.add(carrito);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
        return lista;
    }
}
